# Software-versus-hardware benchmark: development kit

Start with docs/benchmark.md for Vivado GUI tests 28-30.
Open docs/presentation_demo.html in a browser for recorded simulation results.
This ZIP contains no bitstream: live OLED benchmark integration is still next.
Your existing physical display lab kit remains the board-testing baseline.
